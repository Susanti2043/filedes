<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;

class Buku extends Model
{
    use HasFactory;

    protected $table = 'buku';

    protected $fillable = [
        'judul',
        'pengarang',
        'kategori',
    ];

    /**
     * Relasi hasMany ke model Peminjaman.
     */
    public function peminjaman()
    {
        return $this->hasMany(Peminjaman::class, 'buku_id', 'id');
    }

    /**
     * Scope query untuk memfilter buku yang tersedia (tidak sedang dipinjam).
     */
    public function scopeTersedia(Builder $query): void
    {
        $query->whereDoesntHave('peminjaman', function ($q) {
            $q->whereNull('tanggal_kembali');
        });
    }
}