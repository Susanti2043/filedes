<?php

namespace App\Filament\Resources;

use App\Filament\Resources\PeminjamanResource\Pages;
use App\Models\Buku;
use App\Models\Peminjaman;
use Carbon\Carbon;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Form;
use Filament\Notifications\Notification;
use Filament\Resources\Resource;
use Filament\Tables\Actions;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;

class PeminjamanResource extends Resource
{
    protected static ?string $model = Peminjaman::class;

    protected static ?string $navigationIcon = 'heroicon-o-arrow-path-rounded-square';
    protected static ?string $navigationLabel = 'Manajemen Peminjaman';
    protected static ?string $modelLabel = 'Peminjaman';
    protected static ?string $pluralModelLabel = 'Peminjaman'; // Label untuk jamak

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Select::make('buku_id')
                    ->label('Buku')
                    ->relationship('buku', 'judul') // Menampilkan judul buku dari relasi
                    ->options(fn (): array => Buku::tersedia()->pluck('judul', 'id')->toArray()) // Hanya tampilkan buku yang tersedia
                    ->searchable()
                    ->required()
                    ->placeholder('Pilih buku yang akan dipinjam'),
                TextInput::make('peminjam')
                    ->required()
                    ->maxLength(255)
                    ->placeholder('Masukkan nama peminjam'),
                DatePicker::make('tanggal_pinjam')
                    ->required()
                    ->default(now()) // Otomatis mengisi tanggal hari ini
                    ->label('Tanggal Pinjam'),
                DatePicker::make('tanggal_kembali')
                    ->nullable() // Bisa kosong jika belum dikembalikan
                    ->label('Tanggal Kembali'),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('buku.judul') // Mengakses judul buku melalui relasi
                    ->label('Judul Buku')
                    ->searchable()
                    ->sortable(),
                TextColumn::make('peminjam')
                    ->searchable()
                    ->sortable()
                    ->label('Peminjam'),
                TextColumn::make('tanggal_pinjam')
                    ->date('d F Y') // Format tanggal yang lebih mudah dibaca
                    ->sortable()
                    ->label('Tanggal Pinjam'),
                TextColumn::make('tanggal_kembali')
                    ->date('d F Y') // Format tanggal yang lebih mudah dibaca
                    ->sortable()
                    ->placeholder('Belum Dikembalikan') // Teks jika tanggal kembali kosong
                    ->label('Tanggal Kembali'),
            ])
            ->filters([
                // Filter untuk peminjaman yang belum dikembalikan
                \Filament\Tables\Filters\Filter::make('belum_dikembalikan')
                    ->label('Belum Dikembalikan')
                    ->query(fn (Builder $query): Builder => $query->whereNull('tanggal_kembali')),
            ])
            ->actions([
                Actions\EditAction::make(),
                // Aksi "Kembalikan"
                Actions\Action::make('kembalikan')
                    ->label('Kembalikan')
                    ->icon('heroicon-o-arrow-uturn-left')
                    ->color('success')
                    ->requiresConfirmation() // Tambahkan konfirmasi
                    ->modalHeading('Konfirmasi Pengembalian Buku')
                    ->modalDescription('Apakah Anda yakin ingin menandai buku ini sudah dikembalikan?')
                    ->modalSubmitActionLabel('Ya, Kembalikan')
                    ->hidden(fn (Peminjaman $record): bool => $record->tanggal_kembali !== null) // Sembunyikan jika sudah dikembalikan
                    ->action(function (Peminjaman $record) {
                        $record->tanggal_kembali = Carbon::now(); // Set tanggal kembali hari ini
                        $record->save();

                        Notification::make()
                            ->title('Buku berhasil dikembalikan!')
                            ->success()
                            ->send();
                    }),
                Actions\DeleteAction::make(),
            ])
            ->bulkActions([
                Actions\BulkActionGroup::make([
                    Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            // Jika ada relasi manager, tambahkan di sini
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListPeminjamen::route('/'),
            'create' => Pages\CreatePeminjaman::route('/create'),
            'edit' => Pages\EditPeminjaman::route('/{record}/edit'),
        ];
    }
}